package org.react.boot.team.dao;

import java.util.List;

import org.react.boot.team.model.Product;

public interface ProductsDAO {
	
	List<Product> products();

	boolean deleteProduct(String productId);

	boolean addProduct(Product product);

	boolean updateProduct(Product product);

}
