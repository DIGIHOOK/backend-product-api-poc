package org.react.boot.team.dao.client;

import java.util.List;

import org.react.boot.team.model.Product;

public interface ClientBD {

	List<Product> fetchALLProducts();
	
	boolean removeProductById(String productId);

	boolean addProduct(Product product);

	boolean updateProduct(Product product);
}


