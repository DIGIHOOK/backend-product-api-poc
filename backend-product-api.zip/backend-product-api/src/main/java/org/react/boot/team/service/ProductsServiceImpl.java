package org.react.boot.team.service;

import java.util.ArrayList;
import java.util.List;

import org.react.boot.team.dao.ProductsDAO;
import org.react.boot.team.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class ProductsServiceImpl  implements ProductsService{

	
	@Autowired
	private ProductsDAO productsDAO;
	
	@Override
	public List<Product> products() {
		
		List<Product> products=productsDAO.products();
		
		return products;
	}

	@Override
	public boolean deleteProduct(String productId) {
		boolean productDelete=productsDAO.deleteProduct(productId);
		return productDelete;
	}

	@Override
	public boolean addProduct(Product product) {
		boolean productAdded=productsDAO.addProduct(product);
		return productAdded;
	}

	@Override
	public boolean updateProduct(Product product) {
		boolean productUpdated=productsDAO.updateProduct(product);
		return productUpdated;
	}

}
