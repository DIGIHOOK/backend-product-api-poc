package org.react.boot.team.service;

import java.util.List;

import org.react.boot.team.model.Product;

public interface ProductsService {
	
	/**
	 * 
	 * @return list of {@link Product}
	 */
	List<Product> products();

	boolean deleteProduct(String productId);

	boolean addProduct(Product product);

	boolean updateProduct(Product product);
}
