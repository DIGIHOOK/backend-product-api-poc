package org.react.boot.team.model;

public class Product {

	private String id;

	private String name;

	public Product() {
	}
	
	public Product(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public boolean equals(Object obj) {

		boolean equal = false;

		if (obj instanceof Product) {
			Product product = (Product) obj;
			equal = this.id.equals(product.getId());
		}
		return equal;
	}
}
