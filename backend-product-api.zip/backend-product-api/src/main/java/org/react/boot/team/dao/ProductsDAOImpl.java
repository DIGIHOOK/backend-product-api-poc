package org.react.boot.team.dao;

import java.util.List;

import org.react.boot.team.dao.client.ClientBD;
import org.react.boot.team.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class ProductsDAOImpl implements ProductsDAO{
	
	@Autowired
	private ClientBD ClientBD;

	@Override
	public List<Product> products() {
		List<Product> products = ClientBD.fetchALLProducts();
	
		return products;
	}

	@Override
	public boolean deleteProduct(String productId) {
		boolean productDeleted=ClientBD.removeProductById(productId);
		return productDeleted;
	}

	@Override
	public boolean addProduct(Product product) {
		boolean productAdded=ClientBD.addProduct(product);
		return productAdded;
	}

	@Override
	public boolean updateProduct(Product product) {
		boolean productUpdated=ClientBD.updateProduct(product);
		return productUpdated;
	}

}
