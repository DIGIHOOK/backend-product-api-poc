package org.react.boot.team;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages={"org.react.boot.team"})
public class BackEndProductApi {

	public static void main(String[] args) {
		SpringApplication.run(BackEndProductApi.class, args);
	}

}
