package org.react.boot.team.endpoint;

import java.util.List;

import org.react.boot.team.model.Product;
import org.react.boot.team.service.ProductsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductsEndPoint {

	@Autowired
	private ProductsService productsService;

	@RequestMapping(value = "/products", method = RequestMethod.GET)
	public List<Product> products() {
		List<Product> products = productsService.products();

		return products;
	}

	@RequestMapping(value = "/products/{id}", method = RequestMethod.DELETE)

	public boolean deleteProduct(@PathVariable("id") String productId) {
		boolean productDeleted = productsService.deleteProduct(productId);

		return productDeleted;
	}

	@RequestMapping(value = "/products", method = RequestMethod.POST,consumes="application/json",produces="application/json")
	public boolean addProduct(@RequestBody Product product) {
		boolean productDeleted = productsService.addProduct(product);

		return productDeleted;
	}
	
	@RequestMapping(value = "/products", method = RequestMethod.PUT,consumes="application/json",produces="application/json")
	public boolean updateProduct(@RequestBody Product product) {
		boolean productDeleted = productsService.updateProduct(product);

		return productDeleted;
	}


}