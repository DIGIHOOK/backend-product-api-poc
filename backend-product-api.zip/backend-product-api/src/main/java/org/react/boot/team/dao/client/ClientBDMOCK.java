package org.react.boot.team.dao.client;

import java.util.ArrayList;
import java.util.List;

import org.react.boot.team.model.Product;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
public class ClientBDMOCK implements ClientBD {

	private static List<Product> products = new ArrayList<Product>();

	static {

		products.add(new Product("id 1", "Product 1"));
		products.add(new Product("id 2", "Product 2"));
		products.add(new Product("id 3", "Product 3"));
		products.add(new Product("id 4", "Product 4"));
	}

	@Override
	public List<Product> fetchALLProducts() {
		return products;
	}

	@Override
	public boolean removeProductById(String productId) {

		boolean productRemoved = false;

		Product productWithID = getProductById(productId);

		// le prouit à été bien supprimé
		productRemoved = products.remove(productWithID);

		return productRemoved;
	}

	private Product getProductById(String productId) {

		Product productWithID = null;
		for (Product product : products) {
			// si il s'agit du produit avec l'identifiant passé en paramètre
			if (productId.equals(product.getId())) {
				productWithID = product;
			}
		}

		return productWithID;
	}

	@Override
	public boolean addProduct(Product product) {
		boolean productadded = products.add(product);
		return productadded;
	}

	@Override
	public boolean updateProduct(Product product) {
		boolean ProductUpdated = false;

		boolean productRemoved = removeProductById(product.getId());
		if (productRemoved) {
			ProductUpdated = addProduct(product);
		}

		return ProductUpdated;
	}

}
